import 'package:flutter/material.dart';
import 'package:getitease/SignupScreen/body.dart';

class SignupScreen extends StatelessWidget {
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SignupBody(),
    );
  }
}
