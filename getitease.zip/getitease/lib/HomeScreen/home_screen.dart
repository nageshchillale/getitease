import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:getitease/ProfileScreen/profile_screen.dart';
import 'package:getitease/SearchProduct/search_product.dart';
import 'package:getitease/UploadAdScreen/upload_ad_screen.dart';
import 'package:getitease/WelcomeScreen/welcome_screen.dart';

import '../Widgets/global_var.dart';

class HomeScreen extends StatefulWidget {


  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  FirebaseAuth _auth = FirebaseAuth.instance;

  getMyData()
  {
    FirebaseFirestore.instance.collection('users')
        .doc(uid)
        .get()
        .then((results)
    {
      setState(() {
         userImageUrl= results.data()!['userPhotoUrl'];
         getUserName= results.data()!['userName'];
      });
    });

  }


@override
void initState()
{
  super.initState();
  uid = FirebaseAuth.instance.currentUser!.uid;
  userEmail =FirebaseAuth.instance.currentUser!.email!;
  getMyData();
}
  @override
  Widget build(BuildContext context) {
    return Container(

      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blueAccent, Colors.white],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          stops: [0.0, 0.0], // Corrected stops
          tileMode: TileMode.clamp,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent ,
        appBar: AppBar(
          automaticallyImplyLeading: false,
               actions: [
                 TextButton(
                     onPressed: ()
                     {
                      Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => ProfileScreen()));
                     },
                     child: Padding(
                       padding: EdgeInsets.all(10.0),
                       child: Icon(Icons.person , color: Colors.white, size: 30,),
                     ),
                 ),
                 TextButton(
                   onPressed: ()
                   {
                     Navigator.pushReplacement(context,
                         MaterialPageRoute(builder: (context) => SearchProduct()));
                   },
                   child: Padding(
                     padding: EdgeInsets.all(10.0),
                     child: Icon(Icons.search , color: Colors.white, size: 30,),
                   ),
                 ),

                 TextButton(
                   onPressed: ()
                   {
                     _auth.signOut().then((value){
                       Navigator.pushReplacement(context,
                           MaterialPageRoute(builder: (context) => WelcomeScreen()));
                     });

                   },
                   child: Padding(
                     padding: EdgeInsets.all(10.0),
                     child: Icon(Icons.logout , color: Colors.white, size: 30,),
                   ),
                 ),
               ],
               title: Row(
                 mainAxisAlignment: MainAxisAlignment.start,
                 children: [
                   Padding(
                     padding: const EdgeInsets.only(left: 0.0), // adjust value to control shift
                          child: Image.asset(
                            'assets/images/images/logo_three.png',
                                     height: 150, // reduce from 270 for better AppBar fit
                             ),
                   ),
                 ],
               ),
          centerTitle: false,
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.blueAccent, Colors.white],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                stops: [1.0, 1.0], // Corrected stops
                tileMode: TileMode.clamp,
              ),
            ),
          ),

        ),
        floatingActionButton: FloatingActionButton(
          tooltip: 'Add Post',
          backgroundColor: Colors.blueAccent,
          onPressed: ()
          {
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => UploadAdScreen()));
          },
          child: const Icon(Icons.cloud_upload),
        ),
      ),
    );
  }
}
