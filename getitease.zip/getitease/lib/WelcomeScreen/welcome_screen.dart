import 'package:flutter/material.dart';


import 'body.dart';
class WelcomeScreen extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
   body: WelcomeBody(),
    );
  }
}
