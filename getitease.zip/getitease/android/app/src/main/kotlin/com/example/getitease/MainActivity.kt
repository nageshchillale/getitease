package com.example.getitease

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
